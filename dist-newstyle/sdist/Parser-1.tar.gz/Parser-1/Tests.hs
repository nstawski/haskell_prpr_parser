{-# LANGUAGE OverloadedStrings #-}
module Tests where

import Test.QuickCheck
import Test.HUnit
import Parser
import Types
import Text.Megaparsec
import Data.Text (Text)
import qualified Data.Text as T
import Control.Exception (evaluate)

prConfigCases :: [(Text, Either (ParseErrorBundle Text Void) ParsedLine)]
prConfigCases = [ ("VOLUME Volume1 100", Right (VolumeConfigLine (VolumeValue (Volume "Volume1" 100))))
                , ("VOLUME    DrinkVol     50", Right (VolumeConfigLine (VolumeValue (Volume {volumeName = "DrinkVol", volumeValue = 50}))))
                -- , ("PLATE Example PL4",  Right (PlateConfigLine (PlateValue (PlateConfig "Example" "PL4" (2,4)))))
                -- , ("COMPONENT Component1 A:1 LC_W_Bot_Bot",  Right (ComponentConfigLine (ComponentValue (Component "Component1" (Location "A" [('A',[1])]) LC_W_Bot_Bot))))
                -- , ("SPREAD Component1 A:1 Volume1 LC_W_Bot_Bot opt",  Right (SpreadConfigLine (SpreadAction (Spread "Component1" (Location "A" [('A',[1])]) "Volume1" LC_W_Bot_Bot "opt"))))
                -- , ("TRANSFER A:1 B:1 Volume1 LC_W_Bot_Bot opt",   Right (TransferConfigLine (TransferAction (Transfer (Location "A" [('A',[1])]) (Location "B" [('B',[1])]) "Volume1" LC_W_Bot_Bot "opt"))))
                ]

testPRConfig :: [Test]
testPRConfig = map makeTest (zip [1..] prConfigCases)
  where makeTest (i, (input, expected)) =
          TestCase $
            assertEqual ("testPRConfig " ++ show i) expected (runParser lineParser "" input)

tests :: Test
tests = TestList ([TestLabel ("test" ++ show i) t | (i, t) <- zip [1..] testPRConfig]
                 )

main :: IO Counts
main = runTestTT tests